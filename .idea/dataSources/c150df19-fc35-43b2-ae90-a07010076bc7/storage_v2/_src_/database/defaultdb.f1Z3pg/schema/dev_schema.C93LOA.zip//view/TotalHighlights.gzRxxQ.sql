create view "TotalHighlights"(numberofusers, team, week, totalhighlights) as
SELECT count(DISTINCT highlights.authuser) AS numberofusers,
       highlights.team,
       highlights.week,
       sum(highlights.highlights_created)  AS totalhighlights
FROM dev_schema.highlights
GROUP BY highlights.team, highlights.week;

alter table "TotalHighlights"
    owner to doadmin;

