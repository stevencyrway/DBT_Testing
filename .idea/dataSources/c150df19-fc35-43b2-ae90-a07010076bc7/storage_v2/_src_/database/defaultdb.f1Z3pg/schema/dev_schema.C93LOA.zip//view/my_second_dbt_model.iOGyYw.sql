create view my_second_dbt_model(id) as
SELECT my_first_dbt_model.id
FROM dev_schema.my_first_dbt_model
WHERE my_first_dbt_model.id = 1;

alter table my_second_dbt_model
    owner to doadmin;

